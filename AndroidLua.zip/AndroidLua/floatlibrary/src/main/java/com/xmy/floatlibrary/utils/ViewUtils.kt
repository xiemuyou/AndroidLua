package com.xmy.floatlibrary.utils

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Rect
import android.support.annotation.ColorRes
import android.support.annotation.DrawableRes
import android.support.annotation.IntDef
import android.support.annotation.IntRange
import android.support.v4.content.ContextCompat
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.Window
import android.widget.TextView

/**
 * 視圖工具类
 *
 * @author xiemy2
 * @date 2019/4/11
 */
object ViewUtils {
    private val TAG = "ViewUtils"

    const val START = -100
    const val TOP = -110
    const val END = -120
    const val BOTTOM = -130

    private var rootViewHeight = 0

    fun setTextColor(context: Context?, v: TextView?, @ColorRes textColor: Int) {
        if (v == null || context == null) {
            return
        }
        v.setTextColor(ContextCompat.getColor(context, textColor))
    }

    fun setTextSizeForDip(v: TextView?, textSize: Float) {
        if (v == null) {
            return
        }
        v.setTextSize(TypedValue.COMPLEX_UNIT_DIP, textSize)
    }

    @IntDef(START, TOP, END, BOTTOM)
    @kotlin.annotation.Retention(AnnotationRetention.SOURCE)
    internal annotation class PosRes

    /**
     * 设置TextView Drawable (START, TOP, END, BOTTOM)
     *
     * @param context         上下文
     * @param view            TextView
     * @param draRes          Drawable资源ID
     * @param pos             位置
     * @param drawablePadding 边距
     */
    fun setCompoundDrawables(
        context: Context?, view: TextView?, @DrawableRes draRes: Int, @PosRes pos: Int, @IntRange(
            from = 0
        ) drawablePadding: Int
    ) {
        if (view == null || context == null) {
            return
        }
        val drawable = ContextCompat.getDrawable(context, draRes)
        if (draRes == 0 || pos == 0) {
            view.setCompoundDrawables(null, null, null, null)
            return
        }
        if (drawablePadding > 0) {
            view.compoundDrawablePadding = drawablePadding
        }
        if (drawable == null) {
            return
        }
        //调用setCompoundDrawables时，必须调用Drawable.setBounds()方法,否则图片不显示
        drawable.setBounds(0, 0, drawable.minimumWidth, drawable.minimumHeight)
        when (pos) {
            //设置左图标
            START -> view.setCompoundDrawables(drawable, null, null, null)

            //设置上图标
            TOP -> view.setCompoundDrawables(null, drawable, null, null)

            //设置右图标
            END -> view.setCompoundDrawables(null, null, drawable, null)

            //设置右图标
            BOTTOM -> view.setCompoundDrawables(null, null, null, drawable)

            else -> {
            }
        }
    }

    fun getViewLocationFormXY(view: View): IntArray {
        val location = IntArray(2)
        //获取在当前窗口内的绝对坐标
        view.getLocationInWindow(location)
        //获取在整个屏幕内的绝对坐标
        //        floatImage.getLocationOnScreen(location);
        location[1] -= getStatusBarHeight(view)
        return location
    }

    fun getStatusBarHeight(view: View): Int {
        //获取到状态栏的高度?
        val frame = Rect()
        view.getWindowVisibleDisplayFrame(frame)
        return frame.top
    }

    /**
     * 判断是横屏还是竖屏
     *
     * @return 横屏true/竖屏false
     */
    fun isScreenChange(view: View?): Boolean {
        val mConfiguration = if (view != null && view.resources != null) view.resources.configuration else null
        //屏幕方向 == 横屏
        return mConfiguration != null && mConfiguration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    /**
     * 判断是不是刘海屏
     *
     * @return
     */
    fun isHasCutOut(activity: Activity) {
        val heightPixels = activity.resources.displayMetrics.heightPixels
        Log.e("OMG", "heightPixels:$heightPixels")
        val statusBarHeight = activity.resources.getDimensionPixelSize(
            activity.resources.getIdentifier(
                "status_bar_height",
                "dimen",
                "android"
            )
        )
        Log.e("OMG", "statusBarHeight:$statusBarHeight")
        val navigationBarHeight = activity.resources.getDimensionPixelSize(
            activity.resources.getIdentifier(
                "navigation_bar_height",
                "dimen",
                "android"
            )
        )
        Log.e("OMG", "navigationBarHeight:$navigationBarHeight")

        val decorView = activity.window.decorView
        val rootView = activity.window.findViewById<View>(Window.ID_ANDROID_CONTENT)
        rootView.post {
            // 渲染后求高度
            Log.e("OMG", "decorViewHeight:" + decorView.height)
            rootViewHeight = rootView.height
            Log.e("OMG", "rootViewHeight:$rootViewHeight")
            Log.e("OMG", "<< =============== 忧伤的分割线 ================ >>")
        }
    }
}
