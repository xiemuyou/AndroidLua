package com.xmy.floatlibrary;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.xmy.floatlibrary.widget.FloatView;
import com.xmy.floatlibrary.widget.FloatViewParams;

/**
 * @author xy
 */
public class FloatViewManager {

    private static final String TAG = "FloatViewManager";
    private FloatView floatView;
    private boolean isFloatWindowShowing = false;
    private FrameLayout contentView;
    public static FloatViewParams viewParams;

    /**
     * 添加显示悬浮窗口
     *
     * @param activity 上下文
     */
    public synchronized void showHoverImageView(final Activity activity, final View childView) {
        if (activity == null) {
            Log.e(TAG, "showHoverImageView(Activity activity) Activity can't null!!");
            return;
        }
        View rootView = activity.getWindow().getDecorView().getRootView();
        contentView = rootView.findViewById(android.R.id.content);
        try {
            if (viewParams == null) {
                viewParams = new FloatViewParams();
//                viewParams.statusBarHeight = ActivityUtility.getStatusBarHeight(activity);
//                viewParams.heightPixels = ScreenUtils.heightPixels(activity);
//                viewParams.widthPixels = ScreenUtils.widthPixels(activity);
//                viewParams.setHeight(XYHoverView.floatHeight);
            }
            if (contentView.getTag() == null) {
                floatView = new FloatView(activity,childView);
                contentView.addView(floatView);
                contentView.setTag(floatView);
            } else if (contentView.getTag() instanceof FloatView) {
                floatView = (FloatView) contentView.getTag();
                floatView.closeLeftOrRight();
            }
            isFloatWindowShowing = true;
            if (floatView != null) {
                floatView.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            isFloatWindowShowing = false;
            removeHoverImageView(activity);
        }
    }

    /**
     * 隐藏悬浮
     */
    public void hideHoverImageView() {
        boolean isNoNull = floatView != null || contentView != null && (contentView.getTag() instanceof FloatView);
        if (isNoNull) {
            floatView = floatView != null ? floatView : (FloatView) contentView.getTag();
            floatView.closeLeftOrRight();
            floatView.setVisibility(View.GONE);
        }
    }

    /**
     * 移除悬浮窗
     *
     * @param activity 上下文
     */
    public void removeHoverImageView(Activity activity) {
        if (activity == null) {
            return;
        }
        View rootView = activity.getWindow().getDecorView().getRootView();
        FrameLayout contentView = rootView.findViewById(android.R.id.content);
        if (!isFloatWindowShowing) {
            return;
        }
        isFloatWindowShowing = false;
        try {
            if (contentView != null && contentView.getTag() instanceof FloatView) {
                floatView = (FloatView) contentView.getTag();
                contentView.removeView(floatView);
                contentView.setTag(null);
            }
            floatView = null;
        } catch (Exception e) {
            //nothing
        }
    }

    public void imageSetOnTouchListener() {
        if (floatView != null) {
            floatView.imageSetOnTouchListener();
        }
    }
}

