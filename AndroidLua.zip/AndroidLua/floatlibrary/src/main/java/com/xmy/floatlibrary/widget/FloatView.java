
package com.xmy.floatlibrary.widget;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.xmy.floatlibrary.utils.ViewUtils;

import static com.xmy.floatlibrary.FloatViewManager.viewParams;

/**
 * NonoFloatView:悬浮窗控件V2,普通的实现
 *
 * @author Nonolive-杜乾 Created on 2017/12/12 - 17:16.
 * E-mail:dusan.du@nonolive.com
 */
@SuppressLint("ViewConstructor")
public class FloatView extends FrameLayout {

    private Activity context;
    private View childView;

    private boolean hasAddHoverView;
    private boolean isAnim = false;
    private boolean isActionBar = false;

    private float x;
    private float y;
    private float tx;
    private float ty;
    private float sx;
    private float sy;
    private float mSx;
    private float mSy;
    private float xj;

    private int clickEvent = -1;
    private final int RIGHT_OPEN = 101;
    private final int RIGHT_CLOSE = 102;

    public FloatView(@NonNull Activity context, View childView) {
        super(context);
        this.context = context;
        this.childView = childView;
        initView(context);
    }

    private void initView(Context context) {
        childView = new View(context);
        addView(childView);
        initViewPosition();
        hasAddHoverView = true;
        imageSetOnTouchListener();
        setViewBackground(1);
        post(new Runnable() {
            @Override
            public void run() {
                int y = (int) getPivotY();
                int max = Math.max(viewParams.heightPixels, viewParams.widthPixels);
                int min = Math.min(viewParams.heightPixels, viewParams.widthPixels);
                int temp = (ViewUtils.INSTANCE.isScreenChange(childView) ? min : max) - viewParams.statusBarHeight;
                isActionBar = (temp / 2) > y;
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    public void imageSetOnTouchListener() {
        if (childView == null) {
            return;
        }
        childView.setClickable(true);
        childView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent event) {
//                if (floatImageDrawable == null) {
//                    floatImageDrawable = ResourceUtil.getDrawable(context, ResourceImage.imageHover);
//                }
//                if (floatImageDrawablePress == null) {
//                    floatImageDrawablePress = ResourceUtil.getDrawable(context, ResourceImage.imageHoverPress);
//                }
                //获取到状态栏的高度?
                Rect frame = new Rect();
                childView.getWindowVisibleDisplayFrame(frame);
                // statusBarHeight是系统状态栏的高度
                int statusBarHeight = frame.top;
                // 获取相对屏幕的坐标，即以屏幕左上角为原点
                x = (int) event.getRawX();
                int ah = isActionBar ? 144 /*ActivityUtility.getActionBarHeight(context)*/ : 0;
                y = (int) (event.getRawY() - statusBarHeight - ah);
                switch (event.getAction()) {
                    // 捕获手指触摸按下动作
                    case MotionEvent.ACTION_DOWN:
//                        ResourceUtil.setViewBackground(floatImage, floatImageDrawablePress);
                        // 获取相对View的坐标，即以此View左上角为原点
                        tx = event.getX();
                        ty = event.getY();
                        mSx = x;
                        mSy = y;

                        sx = event.getRawX();
                        sy = event.getRawY();
                        xj = 0;
                        break;

                    // 捕获手指触摸移动动作
                    case MotionEvent.ACTION_MOVE:
//                        ResourceUtil.setViewBackground(floatImage, floatImageDrawablePress);
                        float rx = event.getRawX();
                        float ry = event.getRawY();
                        xj = Math.max(Math.abs(rx - sx), Math.abs(xj));
                        xj = Math.max(Math.abs(ry - sy), Math.abs(xj));
                        updateViewPosition(false);
                        break;

                    // 捕获手指触摸离开动作
                    case MotionEvent.ACTION_UP:
//                        ResourceUtil.setViewBackground(floatImage, floatImageDrawable);
                        updateViewPosition(true);
                        tx = ty = 0;
                        if ((x - mSx) < 5 && (y - mSy) < 5 && xj < 7) {
                            imageClick(context);
                        }
                        break;

                    default:
                        break;
                }
                return true;
            }
        });
    }

    public void initViewPosition() {
        childView.post(
                new Runnable() {
                    @Override
                    public void run() {
                        int left = viewParams.isLeft ? 1 : viewParams.getMaxLeft(FloatView.this);
                        myLayout(left, viewParams.top);
                    }
                }
        );
    }

    public void updateViewPosition(boolean isRefresh) {
        if (!hasAddHoverView) {
            return;
        }
        setViewBackground(3);
        // 更新浮动窗口位置参数
        viewParams.left = (int) (x - tx);
        int top = (int) (y - ty);
        if (isRefresh) {
            if (viewParams.left < viewParams.screenWidth / 2) {
                viewParams.left = 0;
                viewParams.isLeft = true;
            } else {
                viewParams.left = viewParams.getMaxLeft(this);
                viewParams.isLeft = false;
            }
        }
        viewParams.top = top;
        // 刷新显示
        myLayout(viewParams.left, viewParams.top);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        //SizeUtils.dp2px(110F);
        int fWidth = viewParams.width;
        int l = viewParams.left;
        switch (clickEvent) {
            case RIGHT_OPEN:
                l -= fWidth;
                break;

            case RIGHT_CLOSE:
                l += fWidth;
                break;

            default:
                break;
        }
        clickEvent = -1;
        myLayout(l, viewParams.top);
    }

    /**
     * 重新布局
     *
     * @param left 左上角x坐标
     * @param top  左上角y坐标
     */
    public void myLayout(int left, int top) {
        if (childView == null) {
            return;
        }
        clickEvent = -1;

        left = left < 1 ? 1 : left;
        int maxTop = viewParams.getMaxTop(this);
        if (top < 1) {
            top = 1;
        } else if (top > maxTop) {
            top = maxTop;
        }

        int right = left + childView.getWidth();
        int bottom = (top + viewParams.getHeight() + viewParams.statusBarHeight);
        viewParams.left = left;
        viewParams.top = top;
        childView.layout(left, top, right, bottom);
    }

//    public void setFloatListener(final OnGotoSdkClickListener clickListener) {
//        folatLayoutView.getLeftArrow().setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                leftLayoutDismiss();
//            }
//        });
//        folatLayoutView.getUserLayout().setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                if (clickListener != null) {
//                    leftLayoutDismiss();
//                    clickListener.onGotoSdkImageClick(ResourceID.LAYOUT_HOME_ID);
//                }
//            }
//        });
//        folatLayoutView.getMsgLayout().setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                if (clickListener != null) {
//                    leftLayoutDismiss();
//                    clickListener.onGotoSdkImageClick(ResourceID.LAYOUT_MESSAGE_ID);
//                    SharedPreferencesUtil.getInstance(XYSDKGames.appXYContext).commitBoolean(SPConfig.HAS_NEW_MSG, false);
//                }
//            }
//        });
//        floatRightLayout.getRightArrow().setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                rightLayoutDismiss();
//            }
//        });
//        floatRightLayout.getUserLayout().setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                if (clickListener != null) {
//                    rightLayoutDismiss();
//                    clickListener.onGotoSdkImageClick(ResourceID.LAYOUT_HOME_ID);
//                }
//            }
//        });
//        floatRightLayout.getMsgLayout().setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                if (clickListener != null) {
//                    rightLayoutDismiss();
//                    clickListener.onGotoSdkImageClick(ResourceID.LAYOUT_MESSAGE_ID);
//                    SharedPreferencesUtil.getInstance(XYSDKGames.appXYContext).commitBoolean(SPConfig.HAS_NEW_MSG, false);
//                }
//            }
//        });
//    }

    public void closeLeftOrRight() {
        if (childView.getVisibility() == View.VISIBLE) {
            return;
        }
        childView.setVisibility(View.VISIBLE);
        initViewPosition();
    }

    private void leftLayoutDismiss() {
        if (isAnim) {
            return;
        }
        doLeftAnimation(false, true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                folatLayoutView.setVisibility(View.GONE);
                setRedPoint();
            }
        }, 500);
    }

    private void rightLayoutDismiss() {
        clickEvent = RIGHT_CLOSE;
        if (isAnim) {
            return;
        }
        doRightAnimation(false, true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                floatRightLayout.setVisibility(View.GONE);
                setRedPoint();
            }
        }, 500);
    }

    private void setRedPoint() {
//        if (childView.isShowRedPoint()) {
//            floatRedPoint.setVisibility(View.VISIBLE);
//            FloatAnimator.getInstance().showStartAnimator(floatRedPoint);
//        }
    }

    /**
     * 执行左边布局的动画，此时按钮在左边
     *
     * @param isShow    显示或隐藏
     * @param showImage 是否显示悬浮按钮
     */
    private void doLeftAnimation(boolean isShow, final boolean showImage) {
        isAnim = true;
        int delay = 500;
        if (isShow) {
            FloatAnimator.getInstance().startAnimation(childView, -1.0F, 0.0F);
        } else {
            delay = delay + 160;
            FloatAnimator.getInstance().startAnimation(childView, 0.0F, -1.0F);
        }
        if (showImage) {
            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    childView.setVisibility(View.VISIBLE);
                    FloatAnimator.getInstance().startAnimation(childView, -1.0F, 0.0F, 200);
                }
            }, 520);
        }
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                isAnim = false;
            }
        }, delay);
    }

    /**
     * 执行右边布局的动画，此时按钮在右边
     *
     * @param isShow    显示或隐藏
     * @param showImage 是否显示悬浮按钮
     */
    private void doRightAnimation(boolean isShow, final boolean showImage) {
//        isAnim = true;
//        int delay = 500;
//        if (isShow) {
//            FloatAnimator.getInstance().startAnimation(floatRightLayout, 1.0F, 0.0F);
//        } else {
//            delay = delay + 180;
//            FloatAnimator.getInstance().startAnimation(floatRightLayout, 0.0F, 1.0F);
//        }
//        if (showImage) {
//            new Handler().postDelayed(new Runnable() {
//
//                @Override
//                public void run() {
//                    floatImage.setVisibility(View.VISIBLE);
//                    FloatAnimator.getInstance().startAnimation(floatImage, 1.0F, 0.0F, 200);
//                }
//            }, 520);
//        }
//        new Handler().postDelayed(new Runnable() {
//
//            @Override
//            public void run() {
//                isAnim = false;
//            }
//        }, delay);
    }

    /**
     * 悬浮按钮的点击
     *
     * @param context 上下文
     */
    private void imageClick(Context context) {
        setViewBackground(3);
//        StateListDrawable hoverDrawable = CommonSelectorCreator.newSelector(context, ResourceImage.imageHover,
//                ResourceImage.imageHoverPress, ResourceImage.imageHover, ResourceImage.imageHover);
//        ResourceUtil.setViewBackground(floatImage, hoverDrawable);
//        if (isAnim) {
//            return;
//        }
//        isAnim = true;
//        if (viewParams.isLeft) {
//            folatLayoutView.setVisibility(View.VISIBLE);
//            floatImage.setVisibility(View.GONE);
//            doLeftAnimation(true, false);
//        } else {
//            clickEvent = RIGHT_OPEN;
//            floatImage.setVisibility(View.GONE);
//            floatRightLayout.setVisibility(View.VISIBLE);
//            doRightAnimation(true, false);
//        }
//        floatRedPoint.setVisibility(View.GONE);
//        if (childView.isShowRedPoint()) {
//            folatLayoutView.showMsgPoint();
//            floatRightLayout.showMsgPoint();
//        } else {
//            floatRightLayout.hideMsgPoint();
//            folatLayoutView.hideMsgPoint();
//        }
    }

    private static final int SET_VIEW_BACKGROUND = 100;

    private void setViewBackground(int seconds) {
//        handler.removeMessages(SET_VIEW_BACKGROUND);
//        long uptimeMillis = seconds * 1000;
//        handler.sendMessageDelayed(handler.obtainMessage(SET_VIEW_BACKGROUND), uptimeMillis);
    }

//    private TaskHandler handler = new TaskHandler<HandleMessageCallback>(new HandleMessageCallback() {
//
//        @Override
//        public void handleMessage(Message msg) {
//            if (msg.what == SET_VIEW_BACKGROUND) {
//                if (floatImage != null) {
//                    ResourceUtil.setViewBackground(floatImage, CommonSelectorCreator.newSelector(context,
//                            ResourceImage.imageHoverAlpha50, ResourceImage.imageHoverPress,
//                            ResourceImage.imageHover, ResourceImage.imageHover));
//                }
//            }
//        }
//    });
}
