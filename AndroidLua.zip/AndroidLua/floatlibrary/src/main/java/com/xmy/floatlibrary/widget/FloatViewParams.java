package com.xmy.floatlibrary.widget;

import android.view.View;
import com.xmy.floatlibrary.utils.SizeUtils;
import com.xmy.floatlibrary.utils.ViewUtils;

/**
 * Description:记录悬浮窗的宽高，坐标等信息
 *
 * @author 杜乾-Dusan,Created on 2018/1/24 - 10:28.
 * E-mail:duqian2010@gmail.com
 */
public class FloatViewParams {

    /***控件宽度**/
    public int widthPixels;
    /***控件高度**/
    public int heightPixels;
    /***控件宽度**/
    public int width;
    /***控件高度**/
    private int height;
    /***窗口的宽(根据横竖屏动态计算)**/
    public int screenWidth;
    /***窗口的高(根据横竖屏动态计算)**/
    public int screenHeight;
    /***是否左边**/
    public boolean isLeft;
    /***状态栏高度**/
    public int statusBarHeight;
    public int left, top;

    public FloatViewParams() {
        isLeft = false;
        top = 1;
        left = 1;
    }

    public void setHeight(int height) {
        this.height = SizeUtils.Companion.dp2px(height);
    }

    private void setScreenWidthOrHeight(View view) {
        View rootView = (View) view.getParent();
        int w, h;
        if (rootView != null) {
            w = rootView.getWidth();
            h = rootView.getHeight();
        } else {
            w = widthPixels;
            h = heightPixels;
        }
        int max = Math.max(w, h);
        int min = Math.min(w, h);
        screenHeight = ViewUtils.INSTANCE.isScreenChange(view) ? min : max;
        screenWidth = ViewUtils.INSTANCE.isScreenChange(view) ? max : min;
    }

    int getMaxTop(View view) {
        setScreenWidthOrHeight(view);
        return screenHeight - height;
    }

    int getMaxLeft(View view) {
        setScreenWidthOrHeight(view);
        return screenWidth - height;
    }

    int getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return "FloatViewParams{" +
                "widthPixels=" + widthPixels +
                ", heightPixels=" + heightPixels +
                ", screenWidth=" + screenWidth +
                ", screenHeight=" + screenHeight +
                ", statusBarHeight=" + statusBarHeight +
                '}';
    }
}
